## 1.0.0

- First release
- - But not actually, I forgot to update the package's name to a newer one