## 1.1.0

- Added assets with proper recolored outlines for mortar tube from ClassicItemsReturns
- - The config option for it will automatically be added after running the game with this mod and the newest version of that mod
- If Ancient Scepter is turned into a shard-tier item, it's method to reroll into another red item gets patched to reroll into another shard-tier item instead
- - No it can't turn into a shard
- - Ancient Scepter's "turn into red scrap" option is unaffected because there is no shard-tier scrap

## 1.0.0

- First release
- - But not actually, I forgot to update the package's name to a newer one